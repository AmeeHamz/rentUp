import React from 'react'
import Select from 'react-select'

const options=[
    {label:'React',value:'react'},
    {label:'HTML',value:'react'},
    {label:'CSS',value:'react'},
    {label:'DB',value:'db'},
]

function customSelect({style}){
    return <div style={style}>
        <Select opetion={opetion}/>
    </div>
}

export default customSelect;